import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;

public class ExpenseTrackerGUI {
    private JFrame frame;
    private ExpenseManager expenseManager;

    public ExpenseTrackerGUI() {
        expenseManager = new ExpenseManager();
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Expense Tracker");
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Panel
        JPanel panel = new JPanel();
        frame.getContentPane().add(panel, BorderLayout.CENTER);
        panel.setLayout(new FlowLayout());

        // Add expense button
        JButton addExpenseButton = new JButton("Add Expense");
        panel.add(addExpenseButton);
        addExpenseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open a dialog to add expense
                String category = JOptionPane.showInputDialog("Enter category:");
                String amountStr = JOptionPane.showInputDialog("Enter amount:");
                String dateStr = JOptionPane.showInputDialog("Enter date (YYYY-MM-DD):");
                String itemName = JOptionPane.showInputDialog("Enter item name:");

                // Parse the date input
                LocalDate date = LocalDate.parse(dateStr);
                double amount = Double.parseDouble(amountStr);

                expenseManager.addExpense(category, amount, date, itemName);
            }
        });

        // Display expenses button
        JButton displayExpensesButton = new JButton("Display Expenses");
        panel.add(displayExpensesButton);
        displayExpensesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                expenseManager.displayExpenses();
            }
        });

        // Display category and time (Year) expenses button
        JButton displayCategoryAndTimeButton = new JButton("Display Category and Year Expenses");
        panel.add(displayCategoryAndTimeButton);
        displayCategoryAndTimeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                expenseManager.displayCategoryAndTimeExpenses();
            }
        });

        // Display category and time (Month) expenses button
        JButton displayCategoryAndMonthButton = new JButton("Display Category and Month Expenses");
        panel.add(displayCategoryAndMonthButton);
        displayCategoryAndMonthButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                expenseManager.displayCategoryAndMonthExpenses();
            }
        });

        // Display category and time (Day) expenses button
        JButton displayCategoryAndDayButton = new JButton("Display Category and Day Expenses");
        panel.add(displayCategoryAndDayButton);
        displayCategoryAndDayButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                expenseManager.displayCategoryAndDayExpenses();
            }
        });

        // Show the window
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ExpenseTrackerGUI();
            }
        });
    }
}
