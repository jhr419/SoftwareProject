package EBU6304_stage_1.src;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ModifyCategory extends JDialog {
    private ExpenseManager expenseManager;

    public ModifyCategory(JFrame parent, ExpenseManager expenseManager) {
        super(parent, "Modify Expense Record Category", true);
        this.expenseManager = expenseManager;

        setSize(600, 400);
        setLayout(new BorderLayout());

        String[] columns = {"Category", "Amount", "Date", "Item Name", "Type"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        List<ExpenseRecord> expenseList = expenseManager.getExpenses();
        for (ExpenseRecord record : expenseList) {
            Object[] row = {
                    record.getCategory(),
                    record.getAmount(),
                    record.getDate(),
                    record.getItemName(),
                    record.getTransactionType()
            };
            model.addRow(row);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton modifyButton = new JButton("Modify Category");

        modifyButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                String currentCategory = (String) model.getValueAt(selectedRow, 0);
                String newCategory = JOptionPane.showInputDialog(this, "Enter new category:", currentCategory);

                if (newCategory != null && !newCategory.trim().isEmpty()) {
                    ExpenseRecord record = expenseList.get(selectedRow);
                    ExpenseRecord updatedRecord = new ExpenseRecord(
                            newCategory,
                            record.getAmount(),
                            record.getDate(),
                            record.getItemName(),
                            record.getTransactionType()
                    );

                    boolean success = expenseManager.updateExpense(selectedRow, updatedRecord);
                    if (success) {
                        model.setValueAt(newCategory, selectedRow, 0);
                        JOptionPane.showMessageDialog(this, "Category updated successfully!");
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to update category!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a record to modify.", "Warning", JOptionPane.WARNING_MESSAGE);
            }
        });

        buttonPanel.add(modifyButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }
}
