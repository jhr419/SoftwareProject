import java.io.*;
import java.util.*;

public class FixedIncomeManager {
    private Map<String, Double> fixedIncomes; // {收入来源 -> 收入金额}
    private static final String FIXED_INCOME_FILE = "fixed_incomes.csv";

    public FixedIncomeManager() {
        fixedIncomes = new HashMap<>();
        loadFixedIncomesFromFile();
    }

    // 添加或更新固定收入
    public void setFixedIncome(String source, double amount) {
        fixedIncomes.put(source, amount);
        saveFixedIncomesToFile();
    }

    // 获取所有固定收入
    public Map<String, Double> getAllFixedIncomes() {
        return fixedIncomes;
    }

    // 删除固定收入
    public boolean removeFixedIncome(String source) {
        if (fixedIncomes.containsKey(source)) {
            fixedIncomes.remove(source);
            saveFixedIncomesToFile();
            return true;
        }
        return false;
    }

    // 计算总固定收入
    public double getTotalFixedIncome() {
        return fixedIncomes.values().stream().mapToDouble(Double::doubleValue).sum();
    }

    // 从文件加载固定收入
    private void loadFixedIncomesFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FIXED_INCOME_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length < 2) continue;
                String source = data[0];
                double amount = Double.parseDouble(data[1]);
                fixedIncomes.put(source, amount);
            }
        } catch (IOException e) {
            System.out.println("No previous fixed income data found.");
        }
    }

    // 保存固定收入到文件
    private void saveFixedIncomesToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FIXED_INCOME_FILE))) {
            for (String source : fixedIncomes.keySet()) {
                writer.write(source + "," + fixedIncomes.get(source));
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving fixed income data: " + e.getMessage());
        }
    }

    // 检查支出是否接近或超过固定收入
    public void warnIfExceedingFixedIncome(double totalSpending) {
        double totalIncome = getTotalFixedIncome();
        if (totalSpending > totalIncome) {
            System.out.println("Warning: Your spending exceeds your fixed income!");
        } else if (totalSpending > totalIncome * 0.9) {
            System.out.println("Warning: Your spending is approaching your fixed income limit.");
        }
    }
}