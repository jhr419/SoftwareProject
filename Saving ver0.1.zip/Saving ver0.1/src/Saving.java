import java.util.ArrayList;
import java.util.List;

public class Saving {
    public static class SavingEntry {
        double amount;
        String source; // "manual" or "auto"
        String date;

        public SavingEntry(double amount, String source, String date) {
            this.amount = amount;
            this.source = source;
            this.date = date;
        }

        @Override
        public String toString() {
            return date + "," + amount + "," + source;
        }
    }

    private double initialFund;
    private double targetFund;
    private List<SavingEntry> savingsList;

    public Saving(double initialFund, double targetFund) {
        this.initialFund = initialFund;
        this.targetFund = targetFund;
        this.savingsList = new ArrayList<>();
    }

    public void setTargetFund(double targetFund) {
        this.targetFund = targetFund;
    }

    public void addManualSaving(double amount, String date) {
        savingsList.add(new SavingEntry(amount, "manual", date));
    }

    public void addAutoSaving(double budget, double expenses, String date) {
        double diff = budget - expenses;
        if (diff > 0) {
            savingsList.add(new SavingEntry(diff, "auto", date));
        }
    }

    public double getTotalSavings() {
        double total = initialFund;
        for (SavingEntry entry : savingsList) {
            total += entry.amount;
        }
        return total;
    }

    public boolean isGoalReached() {
        return getTotalSavings() >= targetFund;
    }

    public List<SavingEntry> getSavingsList() {
        return savingsList;
    }
} 