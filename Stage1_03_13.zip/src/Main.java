/**
 * 主类启动应用程序。
 */
public class Main {
    public static void main(String[] args) {
        // 创建记录管理服务
        RecordManager recordManager = new RecordManager();
        recordManager.loadRecords();

        // 创建视图界面
        MainFrame mainFrame = new MainFrame();
        mainFrame.updateRecordList(recordManager.getRecords());

        // 创建控制器
        new RecordController(recordManager, mainFrame);

        // 显示界面
        mainFrame.setVisible(true);
    }
}