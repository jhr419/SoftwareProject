import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * MainFrame 类负责显示 Swing 界面。
 */
public class MainFrame extends JFrame {
    private JTextField dateField;       // 日期输入框
    private JTextField amountField;     // 金额输入框
    private JTextField categoryField;  // 类别输入框
    private JTextField descriptionField; // 描述输入框（可选项）
    private JComboBox<String> typeComboBox; // 交易类型选择框
    private JList<String> recordList;  // 记录列表
    private JButton addButton;         // 添加按钮
    private JButton deleteButton;      // 删除按钮
    private JButton updateButton;      // 确认修改按钮
    private JButton cancelButton;      // 返回按钮

    public MainFrame() {
        setTitle("个人财务管理");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // 初始化界面组件
        initComponents();
    }

    /**
     * 初始化界面组件。
     */
    private void initComponents() {
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        inputPanel.add(new JLabel("日期 (YYYY-MM-DD):"));
        dateField = new JTextField();
        inputPanel.add(dateField);

        inputPanel.add(new JLabel("金额:"));
        amountField = new JTextField();
        inputPanel.add(amountField);

        inputPanel.add(new JLabel("类别:"));
        categoryField = new JTextField();
        inputPanel.add(categoryField);

        inputPanel.add(new JLabel("描述:"));
        descriptionField = new JTextField();
        inputPanel.add(descriptionField);

        inputPanel.add(new JLabel("类型:"));
        typeComboBox = new JComboBox<>(new String[]{"进账", "支出"});
        inputPanel.add(typeComboBox);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        addButton = new JButton("添加");
        deleteButton = new JButton("删除");
        updateButton = new JButton("确认修改");
        cancelButton = new JButton("返回");
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);

        recordList = new JList<>();
        JScrollPane scrollPane = new JScrollPane(recordList);

        // 布局
        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);

        // 为记录列表添加点击事件监听器
        recordList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedIndex = recordList.getSelectedIndex();
                if (selectedIndex >= 0) {
                    // 触发加载记录到输入框的事件
                    fireRecordSelectedEvent(selectedIndex);
                }
            }
        });
    }

    /**
     * 更新记录列表。
     *
     * @param records 财务记录列表
     */
    public void updateRecordList(List<FinancialRecord> records) {
        DefaultListModel<String> model = new DefaultListModel<>();
        for (FinancialRecord record : records) {
            model.addElement(record.toString());
        }
        recordList.setModel(model);
    }

    /**
     * 获取用户输入的日期。
     */
    public String getDate() {
        return dateField.getText();
    }

    /**
     * 获取用户输入的金额。
     */
    public String getAmount() {
        return amountField.getText();
    }

    /**
     * 获取用户输入的类别。
     */
    public String getCategory() {
        return categoryField.getText();
    }

    /**
     * 获取用户输入的描述。
     */
    public String getDescription() {
        return descriptionField.getText();
    }

    /**
     * 获取用户选择的类型。
     */
    public String getKind() {
        return (String) typeComboBox.getSelectedItem();
    }

    /**
     * 获取选中的记录索引。
     */
    public int getSelectedRecordIndex() {
        return recordList.getSelectedIndex();
    }

    /**
     * 设置添加按钮的事件监听器。
     */
    public void setAddButtonListener(ActionListener listener) {
        addButton.addActionListener(listener);
    }

    /**
     * 设置删除按钮的事件监听器。
     */
    public void setDeleteButtonListener(ActionListener listener) {
        deleteButton.addActionListener(listener);
    }

    /**
     * 设置确认修改按钮的事件监听器。
     */
    public void setUpdateButtonListener(ActionListener listener) {
        updateButton.addActionListener(listener);
    }

    /**
     * 设置返回按钮的事件监听器。
     */
    public void setCancelButtonListener(ActionListener listener) {
        cancelButton.addActionListener(listener);
    }

    /**
     * 将选中的记录加载到输入框中。
     *
     * @param record 选中的记录
     */
    public void loadRecordIntoFields(FinancialRecord record) {
        dateField.setText(record.getDate());
        amountField.setText(String.valueOf(Math.abs(record.getAmount())));
        categoryField.setText(record.getCategory());
        descriptionField.setText(record.getDescription());
        typeComboBox.setSelectedItem(record.getAmount() >= 0 ? "进账" : "支出");
    }

    /**
     * 清空输入框。
     */
    public void clearFields() {
        dateField.setText("");
        amountField.setText("");
        categoryField.setText("");
        descriptionField.setText("");
        typeComboBox.setSelectedItem("进账");
    }

    /**
     * 触发记录选中事件。
     *
     * @param selectedIndex 选中的记录索引
     */
    public void fireRecordSelectedEvent(int selectedIndex) {
        for (RecordSelectedListener listener : recordSelectedListeners) {
            listener.onRecordSelected(selectedIndex);
        }
    }

    // 记录选中事件监听器
    private List<RecordSelectedListener> recordSelectedListeners = new ArrayList<>();

    /**
     * 添加记录选中事件监听器。
     */
    public void addRecordSelectedListener(RecordSelectedListener listener) {
        recordSelectedListeners.add(listener);
    }

    /**
     * 记录选中事件监听器接口。
     */
    public interface RecordSelectedListener {
        void onRecordSelected(int selectedIndex);
    }
}