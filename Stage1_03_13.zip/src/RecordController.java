import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * RecordController 类负责处理用户交互逻辑。
 */
public class RecordController {
    private RecordManager recordManager; // 记录管理服务
    private MainFrame mainFrame;        // 视图界面
    private int selectedIndex = -1;    // 当前选中的记录索引

    public RecordController(RecordManager recordManager, MainFrame mainFrame) {
        this.recordManager = recordManager;
        this.mainFrame = mainFrame;

        // 绑定事件监听器
        mainFrame.setAddButtonListener(new AddButtonListener());
        mainFrame.setDeleteButtonListener(new DeleteButtonListener());
        mainFrame.setUpdateButtonListener(new UpdateButtonListener());
        mainFrame.setCancelButtonListener(new CancelButtonListener());

        // 绑定记录选中事件监听器
        mainFrame.addRecordSelectedListener(new RecordSelectedListener());
    }

    /**
     * 添加记录按钮的事件监听器。
     */
    private class AddButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // 获取用户输入
            String date = mainFrame.getDate();
            String amountText = mainFrame.getAmount();
            String category = mainFrame.getCategory();
            String description = mainFrame.getDescription(); // 描述为可选项
            String type = mainFrame.getKind(); // 获取交易类型

            // 验证输入
            if (date.isEmpty() || amountText.isEmpty() || category.isEmpty()) {
                JOptionPane.showMessageDialog(mainFrame, "日期、金额和类别必须填写！", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double amount;
            try {
                amount = Double.parseDouble(amountText);
                if (amount <= 0) {
                    JOptionPane.showMessageDialog(mainFrame, "金额必须大于 0！", "错误", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(mainFrame, "金额必须是有效的数字！", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!isValidDate(date)) {
                JOptionPane.showMessageDialog(mainFrame, "日期格式不正确，请输入 YYYY-MM-DD 格式的日期！", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 根据交易类型调整金额的正负
            if (type.equals("支出")) {
                amount = -amount; // 支出为负数
            }

            // 创建 FinancialRecord 对象并添加到记录管理服务
            recordManager.addRecord(new FinancialRecord(date, amount, category, description));
            mainFrame.updateRecordList(recordManager.getRecords()); // 更新界面
            mainFrame.clearFields(); // 清空输入框
        }
    }

    /**
     * 删除记录按钮的事件监听器。
     */
    private class DeleteButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedIndex = mainFrame.getSelectedRecordIndex();
            if (selectedIndex >= 0) {
                recordManager.deleteRecord(selectedIndex); // 从记录管理服务删除记录
                mainFrame.updateRecordList(recordManager.getRecords()); // 更新界面
            } else {
                JOptionPane.showMessageDialog(mainFrame, "请选择要删除的记录！", "警告", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    /**
     * 确认修改按钮的事件监听器。
     */
    private class UpdateButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (selectedIndex < 0) {
                JOptionPane.showMessageDialog(mainFrame, "请选择要修改的记录！", "警告", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // 获取用户输入
            String date = mainFrame.getDate();
            String amountText = mainFrame.getAmount();
            String category = mainFrame.getCategory();
            String description = mainFrame.getDescription(); // 描述为可选项
            String type = mainFrame.getKind(); // 获取交易类型

            // 验证输入
            if (date.isEmpty() || amountText.isEmpty() || category.isEmpty()) {
                JOptionPane.showMessageDialog(mainFrame, "日期、金额和类别必须填写！", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double amount;
            try {
                amount = Double.parseDouble(amountText);
                if (amount <= 0) {
                    JOptionPane.showMessageDialog(mainFrame, "金额必须大于 0！", "错误", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(mainFrame, "金额必须是有效的数字！", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!isValidDate(date)) {
                JOptionPane.showMessageDialog(mainFrame, "日期格式不正确，请输入 YYYY-MM-DD 格式的日期！", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 根据交易类型调整金额的正负
            if (type.equals("支出")) {
                amount = -amount; // 支出为负数
            }

            // 更新选中的记录
            recordManager.updateRecord(selectedIndex, new FinancialRecord(date, amount, category, description));
            mainFrame.updateRecordList(recordManager.getRecords()); // 更新界面
            mainFrame.clearFields(); // 清空输入框
            selectedIndex = -1; // 重置选中的记录索引
        }
    }

    /**
     * 返回按钮的事件监听器。
     */
    private class CancelButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            mainFrame.clearFields(); // 清空输入框
            selectedIndex = -1; // 重置选中的记录索引
        }
    }

    /**
     * 记录选中事件监听器。
     */
    private class RecordSelectedListener implements MainFrame.RecordSelectedListener {
        @Override
        public void onRecordSelected(int selectedIndex) {
            // 加载选中的记录到输入框
            FinancialRecord record = recordManager.getRecords().get(selectedIndex);
            mainFrame.loadRecordIntoFields(record);
            RecordController.this.selectedIndex = selectedIndex; // 保存选中的记录索引
        }
    }

    /**
     * 验证日期格式是否为 YYYY-MM-DD。
     *
     * @param date 日期字符串
     * @return 如果日期格式正确，返回 true；否则返回 false
     */
    private boolean isValidDate(String date) {
        return date.matches("\\d{4}-\\d{2}-\\d{2}");
    }
}