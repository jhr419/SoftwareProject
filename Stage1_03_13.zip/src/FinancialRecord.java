/**
 * FinancialRecord 类表示一笔财务记录。
 */
public class FinancialRecord {
    private String date;         // 记录日期
    private double amount;      // 记录金额（正数表示进账，负数表示支出）
    private String category;    // 记录类别
    private String description; // 记录描述（可选项）

    public FinancialRecord(String date, double amount, String category, String description) {
        this.date = date;
        this.amount = amount;
        this.category = category;
        this.description = description;
    }

    // Getter 方法
    public String getDate() {
        return date;
    }

    public double getAmount() {
        return amount;
    }

    public String getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        // 根据金额的正负显示加号或减号
        String sign = amount >= 0 ? "+" : "-";
        String desc = description.isEmpty() ? "" : " - " + description; // 如果描述为空，则不显示
        return date + "  " + category + "  " + sign + Math.abs(amount) + desc;
    }
}