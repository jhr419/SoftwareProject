import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * RecordManager 类负责管理财务记录。
 */
public class RecordManager {
    private List<FinancialRecord> records = new ArrayList<>(); // 财务记录列表
    private static final String DATA_FILE = "financial_records.csv"; // 数据文件路径

    /**
     * 加载财务记录。
     */
    public void loadRecords() {
        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3) { // 确保数据格式正确
                    String date = parts[0];
                    double amount = Double.parseDouble(parts[1]);
                    String category = parts[2];
                    String description = parts.length > 3 ? parts[3] : ""; // 描述为可选项
                    records.add(new FinancialRecord(date, amount, category, description));
                }
            }
        } catch (IOException e) {
            System.out.println("无法读取文件: " + e.getMessage());
        }
    }

    /**
     * 保存财务记录。
     */
    public void saveRecords() {
        try (FileWriter writer = new FileWriter(DATA_FILE)) {
            for (FinancialRecord record : records) {
                writer.write(record.getDate() + "," + record.getAmount() + "," +
                        record.getCategory() + "," + record.getDescription() + "\n");
            }
        } catch (IOException e) {
            System.out.println("无法写入文件: " + e.getMessage());
        }
    }

    /**
     * 添加一笔财务记录。
     *
     * @param record 财务记录对象
     */
    public void addRecord(FinancialRecord record) {
        records.add(record);
        saveRecords(); // 保存数据到文件
    }

    /**
     * 删除一笔财务记录。
     *
     * @param index 记录索引
     */
    public void deleteRecord(int index) {
        if (index >= 0 && index < records.size()) {
            records.remove(index);
            saveRecords(); // 保存数据到文件
        }
    }

    /**
     * 更新一笔财务记录。
     *
     * @param index  记录索引
     * @param record 新的财务记录对象
     */
    public void updateRecord(int index, FinancialRecord record) {
        if (index >= 0 && index < records.size()) {
            records.set(index, record);
            saveRecords(); // 保存数据到文件
        }
    }

    /**
     * 获取所有财务记录。
     *
     * @return 财务记录列表
     */
    public List<FinancialRecord> getRecords() {
        return records;
    }
}
